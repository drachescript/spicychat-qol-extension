@echo off
setlocal
title SpicyChat QoL - Firefox AMO release build

set "DS_FIREFOX_BUILD_BAT=%~f0"

powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$raw=[System.IO.File]::ReadAllText($env:DS_FIREFOX_BUILD_BAT); $marker='###__SPICYCHAT_FIREFOX_RELEASE_POWERSHELL__###'; $i=$raw.LastIndexOf($marker); if($i -lt 0){ throw 'Embedded PowerShell marker not found.' }; $script=$raw.Substring($i+$marker.Length).TrimStart([char]13,[char]10); Invoke-Expression $script"

if errorlevel 1 (
    echo.
    echo ============================================================
    echo  FIREFOX BUILD FAILED
    echo ============================================================
    pause
    exit /b 1
)

echo.
pause
exit /b 0

###__SPICYCHAT_FIREFOX_RELEASE_POWERSHELL__###
$ErrorActionPreference = 'Stop'

# ------------------------------------------------------------
# Resolve project root robustly.
# This works whether the BAT is kept in the project root or in
# D:\Documents\extentions\spicychat-qol\dev_build.
# ------------------------------------------------------------
$preferredRoot = 'D:\Documents\extentions\spicychat-qol'
$root = $null

if (Test-Path -LiteralPath (Join-Path $preferredRoot 'manifest.json') -PathType Leaf) {
    $root = $preferredRoot
}
else {
    $batPath = $env:DS_FIREFOX_BUILD_BAT
    if ([string]::IsNullOrWhiteSpace($batPath)) {
        throw 'Could not determine the BAT path.'
    }

    $probe = Split-Path -Parent $batPath
    for ($i = 0; $i -lt 6 -and $probe; $i++) {
        $candidateManifest = Join-Path $probe 'manifest.json'
        if (Test-Path -LiteralPath $candidateManifest -PathType Leaf) {
            $root = $probe
            break
        }

        $parent = Split-Path -Parent $probe
        if ($parent -eq $probe) { break }
        $probe = $parent
    }
}

if (-not $root) {
    throw 'Could not find the SpicyChat QoL project root (manifest.json). Expected D:\Documents\extentions\spicychat-qol or one of the BAT parent folders.'
}

$sourceManifest = Join-Path $root 'manifest.json'
$sourceManifestData = Get-Content -LiteralPath $sourceManifest -Raw | ConvertFrom-Json
$version = [string]$sourceManifestData.version
$releaseName = [string]$sourceManifestData.name

if ([string]::IsNullOrWhiteSpace($version)) {
    throw 'manifest.json does not contain a version.'
}
if ([string]::IsNullOrWhiteSpace($releaseName)) {
    throw 'manifest.json does not contain a name.'
}
if ($releaseName -match '(?i)\bDEV\b') {
    throw "Refusing to create a Firefox release package from a DEV manifest name: $releaseName"
}

$buildBase = Join-Path $root 'dev_build'
$stage = Join-Path $buildBase 'spicychat-qol-firefox'
$zip = Join-Path $buildBase ("spicychat-qol-v{0}-firefox.zip" -f $version)
$stageManifest = Join-Path $stage 'manifest.json'

# Keep the existing AMO listing identity so current Firefox users receive updates.
$firefoxId = 'spicychat-qol-dev@drache.uk'
$firefoxMinVersion = '140.0'
$firefoxAndroidMinVersion = '142.0'
$homepage = 'https://spicychatqol.drache.uk/'

Write-Host ''
Write-Host '============================================================'
Write-Host ' SpicyChat QoL - Firefox AMO release build'
Write-Host ' SCRIPT REVISION: v0.2-existing-amo-listing'
Write-Host '============================================================'
Write-Host ('Source: ' + $root)
Write-Host ('Stage : ' + $stage)
Write-Host ('ZIP   : ' + $zip)
Write-Host ''

if ($stage -notlike "$root\dev_build\*") {
    throw "Safety check failed: stage is not inside $root\dev_build"
}
if ($zip -notlike "$root\dev_build\*") {
    throw "Safety check failed: ZIP is not inside $root\dev_build"
}

New-Item -ItemType Directory -Force -Path $buildBase | Out-Null

Write-Host '[1/9] Cleaning previous Firefox release build...'
Get-ChildItem -LiteralPath $buildBase -Filter 'spicychat-qol-v*-firefox.zip' -File -ErrorAction SilentlyContinue |
    Remove-Item -Force
if (Test-Path -LiteralPath $stage -PathType Container) {
    Remove-Item -LiteralPath $stage -Recurse -Force
}
New-Item -ItemType Directory -Force -Path $stage | Out-Null

Write-Host '[2/9] Copying current QoL source...'

$excludedTopLevel = @(
    'dragon-dev-reload.js',
    'dragon-dev-worker.js'
)

Get-ChildItem -LiteralPath $root -File | Where-Object {
    $_.Extension -in @('.js', '.css', '.html') -and
    $_.Name -notin $excludedTopLevel
} | ForEach-Object {
    Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $stage $_.Name) -Force
}

Copy-Item -LiteralPath $sourceManifest -Destination $stageManifest -Force

$topLevelDocs = @(
    'CHANGELOG.md',
    'features.md',
    'README.md',
    'RELEASE_NOTES.md',
    'PRIVACY.md',
    'PERMISSIONS.md',
    'SECURITY.md',
    'LICENSE',
    'THIRD-PARTY-NOTICES.md'
)

foreach ($name in $topLevelDocs) {
    $src = Join-Path $root $name
    if (Test-Path -LiteralPath $src -PathType Leaf) {
        Copy-Item -LiteralPath $src -Destination (Join-Path $stage $name) -Force
    }
}

# Copy every top-level source directory except build/output/tooling folders.
# This is more future-proof than assuming only content/ and icons/ exist.
$excludedFolders = @(
    'dev_build',
    'release_build',
    '.git',
    '.github',
    'node_modules',
    'tools',
    'tooling'
)

Get-ChildItem -LiteralPath $root -Directory | Where-Object {
    $_.Name -notin $excludedFolders
} | ForEach-Object {
    $dst = Join-Path $stage $_.Name
    Copy-Item -LiteralPath $_.FullName -Destination $dst -Recurse -Force
}

Write-Host '[3/9] Converting manifest.json for Firefox / AMO...'

$manifest = Get-Content -LiteralPath $stageManifest -Raw | ConvertFrom-Json
$manifest.name = $releaseName

# version_name is Chrome-specific; keep Firefox/AMO manifest clean.
if ($manifest.PSObject.Properties.Name -contains 'version_name') {
    $manifest.PSObject.Properties.Remove('version_name')
}

$manifest.background = [pscustomobject]@{
    scripts = @('background.js')
}

$geckoSettings = [pscustomobject]@{
    id = $firefoxId
    strict_min_version = $firefoxMinVersion
    data_collection_permissions = [pscustomobject]@{
        required = @('none')
        optional = @(
            'authenticationInfo',
            'personalCommunications',
            'websiteContent'
        )
    }
}

$manifest | Add-Member -NotePropertyName browser_specific_settings -NotePropertyValue ([pscustomobject]@{
    gecko = $geckoSettings
    gecko_android = [pscustomobject]@{ strict_min_version = $firefoxAndroidMinVersion }
}) -Force

$manifest | Add-Member -NotePropertyName homepage_url -NotePropertyValue $homepage -Force

Write-Host '[4/9] Creating Firefox-sized icons...'

$iconsDir = Join-Path $stage 'icons'
$icon128 = Join-Path $iconsDir 'icon.jpg'
$icon48 = Join-Path $iconsDir 'icon48.jpg'
$icon96 = Join-Path $iconsDir 'icon96.jpg'

if (-not (Test-Path -LiteralPath $icon128 -PathType Leaf)) {
    throw "Base icon not found: $icon128"
}

Add-Type -AssemblyName System.Drawing

function New-ResizedJpeg([string]$source, [string]$destination, [int]$size) {
    $img = [System.Drawing.Image]::FromFile($source)
    try {
        $bmp = New-Object System.Drawing.Bitmap($size, $size)
        try {
            $graphics = [System.Drawing.Graphics]::FromImage($bmp)
            try {
                $graphics.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
                $graphics.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::HighQuality
                $graphics.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
                $graphics.DrawImage($img, 0, 0, $size, $size)
            }
            finally {
                $graphics.Dispose()
            }
            $bmp.Save($destination, [System.Drawing.Imaging.ImageFormat]::Jpeg)
        }
        finally {
            $bmp.Dispose()
        }
    }
    finally {
        $img.Dispose()
    }
}

New-ResizedJpeg $icon128 $icon48 48
New-ResizedJpeg $icon128 $icon96 96

$iconMap = [pscustomobject]@{
    '48' = 'icons/icon48.jpg'
    '96' = 'icons/icon96.jpg'
    '128' = 'icons/icon.jpg'
}

$manifest | Add-Member -NotePropertyName icons -NotePropertyValue $iconMap -Force

if (-not $manifest.action) {
    $manifest | Add-Member -NotePropertyName action -NotePropertyValue ([pscustomobject]@{}) -Force
}
$manifest.action | Add-Member -NotePropertyName default_icon -NotePropertyValue $iconMap -Force

$json = $manifest | ConvertTo-Json -Depth 100
$utf8NoBom = New-Object System.Text.UTF8Encoding($false)
[System.IO.File]::WriteAllText($stageManifest, $json, $utf8NoBom)

Write-Host '[5/9] Applying Firefox AMO compatibility fixes...'

$listFill = Join-Path $stage 'content\list-fill.js'
$listFillPatched = $false

if (Test-Path -LiteralPath $listFill -PathType Leaf) {
    $listText = [System.IO.File]::ReadAllText($listFill)

    # AMO warning seen in QoL 6:
    # wrapperFromHtml() used template.innerHTML with a dynamic serialized card.
    $wrapperPattern = '(?ms)^  function wrapperFromHtml\(html\) \{\r?\n\s*const template = document\.createElement\("template"\);\r?\n\s*template\.innerHTML = String\(html \|\| ""\)\.trim\(\);\r?\n\s*return template\.content\.firstElementChild \|\| null;\r?\n\s*\}'

    $safeWrapper = @'
  function wrapperFromHtml(html) {
    const source = String(html || "").trim();
    if (!source) return null;

    const parsed = new DOMParser().parseFromString(source, "text/html");
    const root = parsed.body.firstElementChild;
    if (!root) return null;

    root.querySelectorAll("script, iframe, object, embed").forEach(node => node.remove());

    for (const node of [root, ...root.querySelectorAll("*")]) {
      for (const attr of [...node.attributes]) {
        const name = String(attr.name || "").toLowerCase();
        const value = String(attr.value || "").trim().toLowerCase();

        if (name.startsWith("on") || name === "srcdoc") {
          node.removeAttribute(attr.name);
          continue;
        }

        if ((name === "href" || name === "src") && value.startsWith("javascript:")) {
          node.removeAttribute(attr.name);
        }
      }
    }

    return root;
  }
'@

    if ([regex]::IsMatch($listText, $wrapperPattern)) {
        $listText = [regex]::Replace(
            $listText,
            $wrapperPattern,
            [System.Text.RegularExpressions.MatchEvaluator]{ param($m) $safeWrapper },
            1
        )
        [System.IO.File]::WriteAllText($listFill, $listText, $utf8NoBom)
        $listFillPatched = $true
        Write-Host '      patched content/list-fill.js dynamic innerHTML for AMO'
    }
    elseif ($listText -match 'new DOMParser\(\)\.parseFromString\(source,\s*"text/html"\)') {
        Write-Host '      content/list-fill.js AMO fix already present'
    }
    else {
        Write-Host '      NOTE: old wrapperFromHtml pattern not found; source layout changed.'
    }

    $verifyListText = [System.IO.File]::ReadAllText($listFill)
    if ($verifyListText -match 'template\.innerHTML\s*=\s*String\(html\s*\|\|') {
        throw 'Firefox AMO compatibility fix failed: dynamic wrapperFromHtml innerHTML is still present in staged content/list-fill.js.'
    }
}

Write-Host '[6/9] Checking Firefox-specific shared-code support...'

$optionsJs = Join-Path $stage 'options.js'
$backgroundJs = Join-Path $stage 'background.js'
$firefoxConsentReady = $false

if ((Test-Path -LiteralPath $optionsJs -PathType Leaf) -and
    (Test-Path -LiteralPath $backgroundJs -PathType Leaf)) {
    $optionsText = [System.IO.File]::ReadAllText($optionsJs)
    $backgroundText = [System.IO.File]::ReadAllText($backgroundJs)

    if (($optionsText -match 'data_collection') -and ($backgroundText -match 'data_collection')) {
        $firefoxConsentReady = $true
        Write-Host '      DeepL Firefox data-consent handling detected'
    }
    else {
        Write-Host '      NOTE: DeepL data-consent runtime handling was not detected in both shared files'
    }
}

Write-Host '[7/9] Verifying Firefox manifest and referenced files...'

# Build/output folders must never be packaged into the extension.
$accidentalBuildDirs = @(
    (Join-Path $stage 'dev_build'),
    (Join-Path $stage 'release_build')
) | Where-Object { Test-Path -LiteralPath $_ -PathType Container }

if ($accidentalBuildDirs.Count -gt 0) {
    throw ('Build verification failed: an output/build directory was copied into the Firefox package: ' + ($accidentalBuildDirs -join ', '))
}

$manifest = Get-Content -LiteralPath $stageManifest -Raw | ConvertFrom-Json

if ($manifest.name -ne $releaseName) {
    throw "Manifest name verification failed: $($manifest.name)"
}
if ($manifest.background.scripts -notcontains 'background.js') {
    throw 'Firefox background.scripts conversion failed.'
}
if ($manifest.background.PSObject.Properties.Name -contains 'service_worker') {
    throw 'Firefox manifest still contains background.service_worker.'
}
if ($manifest.browser_specific_settings.gecko.id -ne $firefoxId) {
    throw 'Firefox add-on ID verification failed.'
}
if (-not ($manifest.browser_specific_settings.PSObject.Properties.Name -contains 'gecko_android')) {
    throw 'Firefox for Android support is missing: browser_specific_settings.gecko_android was not written.'
}

$missing = New-Object System.Collections.Generic.List[string]

function Test-ManifestFile([string]$relativePath) {
    if ([string]::IsNullOrWhiteSpace($relativePath)) { return }

    # Ignore wildcard web-accessible-resource patterns.
    if ($relativePath.Contains('*')) { return }

    $normalized = $relativePath -replace '/', '\'
    $full = Join-Path $stage $normalized
    if (-not (Test-Path -LiteralPath $full -PathType Leaf)) {
        $script:missing.Add($relativePath)
    }
}

foreach ($bg in @($manifest.background.scripts)) {
    Test-ManifestFile $bg
}
foreach ($cs in @($manifest.content_scripts)) {
    foreach ($js in @($cs.js)) { Test-ManifestFile $js }
    foreach ($css in @($cs.css)) { Test-ManifestFile $css }
}
if ($manifest.action.default_popup) { Test-ManifestFile $manifest.action.default_popup }
if ($manifest.options_page) { Test-ManifestFile $manifest.options_page }
if ($manifest.options_ui.page) { Test-ManifestFile $manifest.options_ui.page }

if ($manifest.icons) {
    foreach ($property in $manifest.icons.PSObject.Properties) {
        Test-ManifestFile ([string]$property.Value)
    }
}
if ($manifest.action.default_icon) {
    if ($manifest.action.default_icon -is [string]) {
        Test-ManifestFile ([string]$manifest.action.default_icon)
    }
    else {
        foreach ($property in $manifest.action.default_icon.PSObject.Properties) {
            Test-ManifestFile ([string]$property.Value)
        }
    }
}
foreach ($war in @($manifest.web_accessible_resources)) {
    foreach ($resource in @($war.resources)) {
        Test-ManifestFile $resource
    }
}

if ($missing.Count -gt 0) {
    $uniqueMissing = $missing | Sort-Object -Unique
    Write-Host ''
    Write-Host 'ERROR: manifest.json references missing files:' -ForegroundColor Red
    foreach ($item in $uniqueMissing) {
        Write-Host ('  - ' + $item) -ForegroundColor Red
    }
    throw 'Firefox release build stopped because required extension files are missing.'
}

Write-Host '[8/9] Creating AMO-safe ZIP...'

Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem

if (Test-Path -LiteralPath $zip) {
    Remove-Item -LiteralPath $zip -Force
}

$zipStream = [System.IO.File]::Open(
    $zip,
    [System.IO.FileMode]::CreateNew,
    [System.IO.FileAccess]::ReadWrite,
    [System.IO.FileShare]::None
)

try {
    $zipArchive = New-Object System.IO.Compression.ZipArchive(
        $zipStream,
        [System.IO.Compression.ZipArchiveMode]::Create,
        $false
    )

    try {
        $stageFull = [System.IO.Path]::GetFullPath($stage).TrimEnd('\', '/')
        $stagePrefixLength = $stageFull.Length + 1

        Get-ChildItem -LiteralPath $stage -File -Recurse -Force |
            Sort-Object FullName |
            ForEach-Object {
                $fileFull = [System.IO.Path]::GetFullPath($_.FullName)

                if (-not $fileFull.StartsWith($stageFull, [System.StringComparison]::OrdinalIgnoreCase)) {
                    throw "Refusing to ZIP file outside staging folder: $fileFull"
                }

                $entryName = $fileFull.Substring($stagePrefixLength).Replace('\', '/')

                if ([string]::IsNullOrWhiteSpace($entryName)) {
                    throw "Could not create ZIP entry name for: $fileFull"
                }
                if ($entryName.Contains('\')) {
                    throw "AMO-invalid ZIP entry path: $entryName"
                }

                [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile(
                    $zipArchive,
                    $fileFull,
                    $entryName,
                    [System.IO.Compression.CompressionLevel]::Optimal
                ) | Out-Null
            }
    }
    finally {
        if ($null -ne $zipArchive) { $zipArchive.Dispose() }
    }
}
finally {
    $zipStream.Dispose()
}

Write-Host '[9/9] Verifying final Firefox ZIP...'

$archive = [System.IO.Compression.ZipFile]::OpenRead($zip)
try {
    $badPaths = @($archive.Entries | Where-Object { $_.FullName.Contains('\') })
    if ($badPaths.Count -gt 0) {
        throw ('ZIP contains AMO-invalid backslash paths: ' + (($badPaths | ForEach-Object FullName) -join ', '))
    }

    $entry = $archive.Entries |
        Where-Object { $_.FullName -eq 'manifest.json' } |
        Select-Object -First 1

    if (-not $entry) {
        throw 'ZIP verification failed: manifest.json is not at ZIP root.'
    }

    $reader = New-Object System.IO.StreamReader($entry.Open())
    try {
        $zipManifest = $reader.ReadToEnd() | ConvertFrom-Json
    }
    finally {
        $reader.Dispose()
    }

    if ($zipManifest.name -ne $releaseName) {
        throw "ZIP verification failed. Name: $($zipManifest.name)"
    }
    if ($zipManifest.background.scripts -notcontains 'background.js') {
        throw 'ZIP verification failed: Firefox background.scripts missing.'
    }
    if ($zipManifest.background.PSObject.Properties.Name -contains 'service_worker') {
        throw 'ZIP verification failed: service_worker still present.'
    }
    if ($zipManifest.browser_specific_settings.gecko.id -ne $firefoxId) {
        throw 'ZIP verification failed: Firefox add-on ID incorrect.'
    }
    if (-not ($zipManifest.browser_specific_settings.PSObject.Properties.Name -contains 'gecko_android')) {
        throw 'ZIP verification failed: Firefox for Android support is missing.'
    }

    $entryCount = $archive.Entries.Count
}
finally {
    $archive.Dispose()
}

$zipInfo = Get-Item -LiteralPath $zip
$sizeMB = [math]::Round($zipInfo.Length / 1MB, 2)

Write-Host ''
Write-Host '============================================================'
Write-Host ' FIREFOX RELEASE BUILD COMPLETE'
Write-Host '============================================================'
Write-Host ('Source:      ' + $root)
Write-Host ('Stage:       ' + $stage)
Write-Host ('ZIP:         ' + $zip)
Write-Host ('Version:     ' + $version)
Write-Host ('Name:        ' + $releaseName)
Write-Host ('Firefox ID:  ' + $firefoxId)
Write-Host ('Firefox desktop min: ' + $firefoxMinVersion)
Write-Host ('Firefox Android min: ' + $firefoxAndroidMinVersion)
Write-Host 'Android:     enabled via gecko_android'
Write-Host ('Files:       ' + $entryCount)
Write-Host ('ZIP size:    ' + $sizeMB + ' MB')
Write-Host ('AMO paths:   forward slashes verified')
Write-Host ('list-fill:   ' + $(if ($listFillPatched) { 'patched for AMO' } else { 'already safe / no old pattern' }))
Write-Host ('DeepL check: ' + $(if ($firefoxConsentReady) { 'ready' } else { 'review recommended' }))
Write-Host ''

