@echo off
setlocal EnableExtensions EnableDelayedExpansion
title SpicyChat QOL Android - Build + Copy to DEV
echo.
echo SpicyChat QOL Android
echo Build Android and copy the versioned APK to extension dev_build
echo.

set "DEV_BUILD=D:\Documents\extentions\spicychat-qol\dev_build"
set "ANDROID_ROOT=D:\Documents\extentions\spicychat-qol-android"

rem If the expected Android folder is missing, find the project automatically.
if not exist "%ANDROID_ROOT%\build_android.bat" (
  for /d %%D in ("D:\Documents\extentions\*") do (
    if exist "%%~fD\build_android.bat" if exist "%%~fD\android_app\pubspec.yaml" (
      set "ANDROID_ROOT=%%~fD"
      goto :android_found
    )
  )
)

:android_found
if not exist "%ANDROID_ROOT%\build_android.bat" (
  echo ERROR: Could not find the SpicyChat QOL Android project.
  echo Expected: D:\Documents\extentions\spicychat-qol-android\build_android.bat
  echo.
  pause
  exit /b 1
)

if not exist "%DEV_BUILD%" mkdir "%DEV_BUILD%"
if not exist "%DEV_BUILD%" (
  echo ERROR: Could not create/access dev_build:
  echo %DEV_BUILD%
  echo.
  pause
  exit /b 2
)

rem Let the normal Android BAT return without its own pause.
set "DS_NO_PAUSE=1"
call "%ANDROID_ROOT%\build_android.bat"
set "BUILD_EXIT=!ERRORLEVEL!"
set "DS_NO_PAUSE="

if not "!BUILD_EXIT!"=="0" (
  echo.
  echo ERROR: Android build did not finish successfully. Nothing was copied.
  echo Exit code: !BUILD_EXIT!
  echo.
  pause
  exit /b !BUILD_EXIT!
)

set "OUTPUT_DIR=%ANDROID_ROOT%\output"
set "VERSION_FILE=!OUTPUT_DIR!\current-version.txt"
set "APK_NAME="

rem Primary source: exact APK recorded by the successful normal build.
if exist "!VERSION_FILE!" (
  for /f "tokens=1,* delims==" %%A in ('findstr /b /i "apk=" "!VERSION_FILE!" 2^>nul') do set "APK_NAME=%%B"
)

rem Defensive fallback: newest versioned APK in output, never the generic SpicyChat-QOL.apk.
if not defined APK_NAME (
  for /f "delims=" %%F in ('dir /b /a:-d /o:-d "!OUTPUT_DIR!\SpicyChat-QOL-Android-v*.apk" 2^>nul') do (
    if not defined APK_NAME set "APK_NAME=%%F"
  )
)

if not defined APK_NAME (
  echo.
  echo ERROR: Build succeeded but no versioned APK could be found in:
  echo !OUTPUT_DIR!
  echo.
  pause
  exit /b 3
)

set "SOURCE_APK=!OUTPUT_DIR!\!APK_NAME!"
set "DEST_APK=%DEV_BUILD%\!APK_NAME!"

if not exist "!SOURCE_APK!" (
  echo.
  echo ERROR: The versioned APK recorded by the build does not exist.
  echo Expected: !SOURCE_APK!
  echo.
  pause
  exit /b 4
)

copy /y "!SOURCE_APK!" "!DEST_APK!" >nul
if errorlevel 1 (
  echo.
  echo ERROR: APK build succeeded but copying to dev_build failed.
  echo From: !SOURCE_APK!
  echo To:   !DEST_APK!
  echo.
  pause
  exit /b 5
)

if not exist "!DEST_APK!" (
  echo.
  echo ERROR: copy reported success, but the destination APK is missing.
  echo Expected: !DEST_APK!
  echo.
  pause
  exit /b 6
)

for %%S in ("!SOURCE_APK!") do set "SOURCE_SIZE=%%~zS"
for %%D in ("!DEST_APK!") do set "DEST_SIZE=%%~zD"
if not "!SOURCE_SIZE!"=="!DEST_SIZE!" (
  echo.
  echo ERROR: copied APK size does not match the build output.
  echo Source bytes: !SOURCE_SIZE!
  echo Dest bytes:   !DEST_SIZE!
  echo.
  pause
  exit /b 7
)

echo.
echo ====================================================
echo Android build complete and copied to DEV.
echo APK: !APK_NAME!
echo From: !SOURCE_APK!
echo To:   !DEST_APK!
echo Bytes: !DEST_SIZE!
echo ====================================================
echo.
pause
exit /b 0
