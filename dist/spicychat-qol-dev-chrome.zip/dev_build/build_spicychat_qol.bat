@echo off
setlocal
title SpicyChat QoL - Chrome release build

set "DS_CHROME_BUILD_BAT=%~f0"

powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$raw=[System.IO.File]::ReadAllText($env:DS_CHROME_BUILD_BAT); $marker='###__SPICYCHAT_CHROME_RELEASE_POWERSHELL__###'; $i=$raw.LastIndexOf($marker); if($i -lt 0){ throw 'Embedded PowerShell marker not found.' }; $script=$raw.Substring($i+$marker.Length).TrimStart([char]13,[char]10); Invoke-Expression $script"

if errorlevel 1 (
    echo.
    echo ============================================================
    echo  CHROME BUILD FAILED
    echo ============================================================
    pause
    exit /b 1
)

echo.
pause
exit /b 0

###__SPICYCHAT_CHROME_RELEASE_POWERSHELL__###
$ErrorActionPreference = 'Stop'

# ------------------------------------------------------------
# Resolve the project root.
# The BAT can live in the project root, dev_build, or elsewhere.
# ------------------------------------------------------------
$preferredRoot = 'D:\Documents\extentions\spicychat-qol'
$root = $null

if (Test-Path -LiteralPath (Join-Path $preferredRoot 'manifest.json') -PathType Leaf) {
    $root = $preferredRoot
}
else {
    $batPath = $env:DS_CHROME_BUILD_BAT
    if ([string]::IsNullOrWhiteSpace($batPath)) {
        throw 'Could not determine the BAT path.'
    }

    $probe = Split-Path -Parent $batPath
    for ($i = 0; $i -lt 6 -and $probe; $i++) {
        if (Test-Path -LiteralPath (Join-Path $probe 'manifest.json') -PathType Leaf) {
            $root = $probe
            break
        }

        $parent = Split-Path -Parent $probe
        if ($parent -eq $probe) { break }
        $probe = $parent
    }
}

if (-not $root) {
    throw 'Could not find the SpicyChat QoL project root (manifest.json). Expected D:\Documents\extentions\spicychat-qol or one of the BAT parent folders.'
}

$sourceManifest = Join-Path $root 'manifest.json'
$sourceManifestData = Get-Content -LiteralPath $sourceManifest -Raw | ConvertFrom-Json
$version = [string]$sourceManifestData.version
$releaseName = [string]$sourceManifestData.name

if ([string]::IsNullOrWhiteSpace($version)) {
    throw 'manifest.json does not contain a version.'
}
if ([string]::IsNullOrWhiteSpace($releaseName)) {
    throw 'manifest.json does not contain a name.'
}
if ($releaseName -match '(?i)\bDEV\b') {
    throw "Refusing to create a release package from a DEV manifest name: $releaseName"
}

$buildBase = Join-Path $root 'dev_build'
$stage = Join-Path $buildBase 'spicychat-qol-chrome'
$zip = Join-Path $buildBase ("spicychat-qol-v{0}-chrome.zip" -f $version)
$stageManifest = Join-Path $stage 'manifest.json'

Write-Host ''
Write-Host '============================================================'
Write-Host ' SpicyChat QoL - Chrome release build'
Write-Host '============================================================'
Write-Host ('Source : ' + $root)
Write-Host ('Version: ' + $version)
Write-Host ('Stage  : ' + $stage)
Write-Host ('ZIP    : ' + $zip)
Write-Host ''

if ($stage -notlike "$root\dev_build\*") {
    throw "Safety check failed: stage is not inside $root\dev_build"
}
if ($zip -notlike "$root\dev_build\*") {
    throw "Safety check failed: ZIP is not inside $root\dev_build"
}

New-Item -ItemType Directory -Force -Path $buildBase | Out-Null

Write-Host '[1/6] Cleaning previous Chrome build...'
Get-ChildItem -LiteralPath $buildBase -Filter 'spicychat-qol-v*-chrome.zip' -File -ErrorAction SilentlyContinue |
    Remove-Item -Force
if (Test-Path -LiteralPath $stage -PathType Container) {
    Remove-Item -LiteralPath $stage -Recurse -Force
}
New-Item -ItemType Directory -Force -Path $stage | Out-Null

Write-Host '[2/6] Copying extension files...'

$excludedTopLevel = @(
    'dragon-dev-reload.js',
    'dragon-dev-worker.js',
    'dragon-dev-server.js',
    'dragon-dev-reload.config.json',
    'manifest.before-dragon-reload.json'
)

# Runtime/source files at the project root.
Get-ChildItem -LiteralPath $root -File | Where-Object {
    $_.Extension.ToLowerInvariant() -in @('.js', '.css', '.html') -and
    $_.Name -notin $excludedTopLevel
} | ForEach-Object {
    Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $stage $_.Name) -Force
}

Copy-Item -LiteralPath $sourceManifest -Destination $stageManifest -Force

# Release-facing docs that are useful in source/store packages without copying
# every unrelated markdown/json file from the working tree.
$topLevelDocs = @(
    'CHANGELOG.md',
    'features.md',
    'README.md',
    'RELEASE_NOTES.md',
    'PRIVACY.md',
    'PERMISSIONS.md',
    'SECURITY.md',
    'THIRD-PARTY-NOTICES.md',
    'LICENSE'
)

foreach ($name in $topLevelDocs) {
    $src = Join-Path $root $name
    if (Test-Path -LiteralPath $src -PathType Leaf) {
        Copy-Item -LiteralPath $src -Destination (Join-Path $stage $name) -Force
    }
}

# Copy extension source directories while keeping build/tooling folders out.
$excludedFolders = @(
    'dev_build',
    'release_build',
    '.git',
    '.github',
    'node_modules',
    'tools',
    'tooling'
)

Get-ChildItem -LiteralPath $root -Directory | Where-Object {
    $_.Name -notin $excludedFolders
} | ForEach-Object {
    Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $stage $_.Name) -Recurse -Force
}

Write-Host '[3/6] Preparing Chrome manifest...'
$manifest = Get-Content -LiteralPath $stageManifest -Raw | ConvertFrom-Json

# Keep Firefox-only packaging metadata out of the Chrome package.
if ($manifest.PSObject.Properties.Name -contains 'browser_specific_settings') {
    $manifest.PSObject.Properties.Remove('browser_specific_settings')
}

# Chrome should use the service worker form from the shared source manifest.
if (-not $manifest.background -or -not $manifest.background.service_worker) {
    throw 'Chrome manifest must contain background.service_worker.'
}

$utf8NoBom = New-Object System.Text.UTF8Encoding($false)
$json = $manifest | ConvertTo-Json -Depth 100
[System.IO.File]::WriteAllText($stageManifest, $json, $utf8NoBom)

Write-Host '[4/6] Verifying manifest references...'

$accidentalBuildDirs = @(
    (Join-Path $stage 'dev_build'),
    (Join-Path $stage 'release_build')
) | Where-Object { Test-Path -LiteralPath $_ -PathType Container }

if ($accidentalBuildDirs.Count -gt 0) {
    throw ('Build verification failed: output/build directory copied into package: ' + ($accidentalBuildDirs -join ', '))
}

$manifest = Get-Content -LiteralPath $stageManifest -Raw | ConvertFrom-Json
if ($manifest.name -ne $releaseName) {
    throw "Manifest name verification failed: $($manifest.name)"
}
if ($manifest.version -ne $version) {
    throw "Manifest version verification failed: $($manifest.version)"
}
if (-not $manifest.background.service_worker) {
    throw 'Chrome service worker verification failed.'
}

$missing = New-Object System.Collections.Generic.List[string]
function Test-ManifestFile([string]$relativePath) {
    if ([string]::IsNullOrWhiteSpace($relativePath)) { return }
    if ($relativePath.Contains('*')) { return }

    $normalized = $relativePath -replace '/', '\'
    $full = Join-Path $stage $normalized
    if (-not (Test-Path -LiteralPath $full -PathType Leaf)) {
        $script:missing.Add($relativePath)
    }
}

Test-ManifestFile ([string]$manifest.background.service_worker)
foreach ($cs in @($manifest.content_scripts)) {
    foreach ($js in @($cs.js)) { Test-ManifestFile $js }
    foreach ($css in @($cs.css)) { Test-ManifestFile $css }
}
if ($manifest.action.default_popup) { Test-ManifestFile $manifest.action.default_popup }
if ($manifest.options_page) { Test-ManifestFile $manifest.options_page }
if ($manifest.options_ui.page) { Test-ManifestFile $manifest.options_ui.page }
if ($manifest.icons) {
    foreach ($property in $manifest.icons.PSObject.Properties) {
        Test-ManifestFile ([string]$property.Value)
    }
}
if ($manifest.action.default_icon) {
    if ($manifest.action.default_icon -is [string]) {
        Test-ManifestFile ([string]$manifest.action.default_icon)
    }
    else {
        foreach ($property in $manifest.action.default_icon.PSObject.Properties) {
            Test-ManifestFile ([string]$property.Value)
        }
    }
}
foreach ($war in @($manifest.web_accessible_resources)) {
    foreach ($resource in @($war.resources)) {
        Test-ManifestFile $resource
    }
}

if ($missing.Count -gt 0) {
    $uniqueMissing = $missing | Sort-Object -Unique
    Write-Host ''
    Write-Host 'ERROR: manifest.json references missing files:' -ForegroundColor Red
    foreach ($item in $uniqueMissing) {
        Write-Host ('  - ' + $item) -ForegroundColor Red
    }
    throw 'Chrome build stopped because required extension files are missing.'
}

Write-Host '[5/6] Creating Chrome ZIP...'
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem

if (Test-Path -LiteralPath $zip) {
    Remove-Item -LiteralPath $zip -Force
}

$zipStream = [System.IO.File]::Open(
    $zip,
    [System.IO.FileMode]::CreateNew,
    [System.IO.FileAccess]::ReadWrite,
    [System.IO.FileShare]::None
)

try {
    $zipArchive = New-Object System.IO.Compression.ZipArchive(
        $zipStream,
        [System.IO.Compression.ZipArchiveMode]::Create,
        $false
    )

    try {
        $stageFull = [System.IO.Path]::GetFullPath($stage).TrimEnd('\', '/')
        $stagePrefixLength = $stageFull.Length + 1

        Get-ChildItem -LiteralPath $stage -File -Recurse -Force |
            Sort-Object FullName |
            ForEach-Object {
                $fileFull = [System.IO.Path]::GetFullPath($_.FullName)
                if (-not $fileFull.StartsWith($stageFull, [System.StringComparison]::OrdinalIgnoreCase)) {
                    throw "Refusing to ZIP file outside staging folder: $fileFull"
                }

                $entryName = $fileFull.Substring($stagePrefixLength).Replace('\', '/')
                if ([string]::IsNullOrWhiteSpace($entryName)) {
                    throw "Could not create ZIP entry name for: $fileFull"
                }

                [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile(
                    $zipArchive,
                    $fileFull,
                    $entryName,
                    [System.IO.Compression.CompressionLevel]::Optimal
                ) | Out-Null
            }
    }
    finally {
        if ($null -ne $zipArchive) { $zipArchive.Dispose() }
    }
}
finally {
    $zipStream.Dispose()
}

Write-Host '[6/6] Verifying final Chrome ZIP...'
$archive = [System.IO.Compression.ZipFile]::OpenRead($zip)
try {
    $entry = $archive.Entries | Where-Object { $_.FullName -eq 'manifest.json' } | Select-Object -First 1
    if (-not $entry) {
        throw 'ZIP verification failed: manifest.json is not at ZIP root.'
    }

    $reader = New-Object System.IO.StreamReader($entry.Open())
    try {
        $zipManifest = $reader.ReadToEnd() | ConvertFrom-Json
    }
    finally {
        $reader.Dispose()
    }

    if ($zipManifest.name -ne $releaseName) {
        throw "ZIP verification failed. Name: $($zipManifest.name)"
    }
    if ($zipManifest.version -ne $version) {
        throw "ZIP verification failed. Version: $($zipManifest.version)"
    }
    if (-not $zipManifest.background.service_worker) {
        throw 'ZIP verification failed: background.service_worker missing.'
    }
    if ($zipManifest.PSObject.Properties.Name -contains 'browser_specific_settings') {
        throw 'ZIP verification failed: Firefox-only browser_specific_settings remained in Chrome package.'
    }

    $entryCount = $archive.Entries.Count
}
finally {
    $archive.Dispose()
}

$zipInfo = Get-Item -LiteralPath $zip
$sizeMB = [math]::Round($zipInfo.Length / 1MB, 2)

Write-Host ''
Write-Host '============================================================'
Write-Host ' CHROME RELEASE BUILD COMPLETE'
Write-Host '============================================================'
Write-Host ('Source:   ' + $root)
Write-Host ('Stage:    ' + $stage)
Write-Host ('ZIP:      ' + $zip)
Write-Host ('Version:  ' + $version)
Write-Host ('Name:     ' + $releaseName)
Write-Host ('Files:    ' + $entryCount)
Write-Host ('ZIP size: ' + $sizeMB + ' MB')
Write-Host ''
